<?php
namespace cs174\hw3\configs;

const DB_USR = "root";
const DB_PWD = "password";
const DB_PRT = "3306";
