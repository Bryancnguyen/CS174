<?php
namespace cs174\hw3\controllers;

//Figure out how to handle When user adds a new list
class NoteController {
public function addNewNote()
{
  //Call DB to add new category
}

public function getNote()
{
  //Call DB to add new category
}
}
