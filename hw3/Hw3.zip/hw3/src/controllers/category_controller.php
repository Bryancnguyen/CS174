<?php
namespace cs174\hw3\controllers;

class CategoryController {
//Figure out how to handle When user adds a new list
public function addNewCategoryList()
{
  //Call DB to add new category
}

public function getCategory()
{
  //Call DB to add new category
}
}
