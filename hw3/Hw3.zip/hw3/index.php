<?php

include('./src/controllers/page_controller.php');
$page_controller = new cs174\hw3\controllers\PageController();
$page_controller->render();
