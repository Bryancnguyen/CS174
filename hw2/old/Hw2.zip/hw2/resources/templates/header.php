<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <link rel="stylesheet" type="text/css" href="./css/style.css"/>
    <link rel="icon" type="image/jpg" href="./resources/doge-favicon-small.jpg">
    <title>My PHP Text Editor</title>
</head>
<body>
<div id="header">
    <h1><a href="./">Simple Text Editor</a></h1>

</div>
