<footer>
  <div class="container fluid">
<p>
  Some Janky Text Editor that works...
  by:
  Bryan Nguyen,
  Jack Wanke, &
  Richard Papalia
</p>
  </div>
</footer>
</body>
</html>
